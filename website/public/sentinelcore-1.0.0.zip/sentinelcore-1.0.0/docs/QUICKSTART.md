# SentinelCore — Quick Start

SentinelCore is a network detection & incident-response platform that runs as
a single `docker compose` stack on one Linux host with a mirrored capture
interface.

## 1. Requirements (minimum)
- Ubuntu 22.04 or 24.04 LTS, x86_64
- 4 CPU cores, 8 GB RAM, 40 GB free disk (8 cores / 16 GB / 100 GB SSD recommended)
- Docker Engine + Docker Compose v2, with root/sudo
- A capture NIC that sees the traffic you want to monitor (a mirror/SPAN port)
- Host port 80 free

## 2. Install
```bash
tar -xf sentinelcore-<version>.zip   # or: unzip
cd sentinelcore-<version>
sudo ./install.sh
```
The installer detects your interfaces and network, generates all secrets,
loads the bundled Docker images (no internet build needed), starts the stack,
and prints the one-time admin password. **Store that password immediately.**

## 3. Open the console
Browse to `http://<host-ip>/` and sign in as `admin` with the printed password.

## 4. Uninstall
```bash
sudo ./uninstall.sh          # stop the stack
sudo ./uninstall.sh --purge  # also remove data volumes (irreversible)
```

## Notes
- All secrets are generated locally; none ship in this package.
- Email notifications (optional) are routed through the SentinelCore relay —
  no mail provider key ever lives on your box.
- See `REQUIREMENTS.md` for the full system-requirement detail.
