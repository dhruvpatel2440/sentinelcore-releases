#!/usr/bin/env bash
# SentinelCore uninstaller. Stops the stack; with --purge also removes data
# volumes and the firewall chain. Always asks before anything destructive.
#
# Usage:
#   sudo ./uninstall.sh            stop + remove containers (keep data)
#   sudo ./uninstall.sh --purge    also remove volumes, .env, CA, systemd unit
#   ./uninstall.sh --dry-run       print actions, change nothing
set -euo pipefail

HERE="$(cd "$(dirname "$0")" && pwd)"
LIB="$HERE/lib"; [ -d "$LIB" ] || LIB="$HERE/../installer/lib"
INSTALL_DIR="${INSTALL_DIR:-/opt/sentinelcore}"
LOG_FILE="${LOG_FILE:-/var/log/sentinelcore-install.log}"
DRY_RUN=0; PURGE=0
declare -A SECRETS=()

while [ $# -gt 0 ]; do
    case "$1" in
        --purge) PURGE=1; shift ;;
        --dry-run) DRY_RUN=1; shift ;;
        -h|--help) sed -n '2,12p' "$0"; exit 0 ;;
        *) echo "unknown option: $1" >&2; exit 2 ;;
    esac
done

{ : >>"$LOG_FILE"; } 2>/dev/null || LOG_FILE="${TMPDIR:-/tmp}/sentinelcore-install.log"
# shellcheck disable=SC1090
. "$LIB/ui.sh"

SUDO=""; [ "$(id -u)" -eq 0 ] || SUDO="sudo"

step "SentinelCore uninstall"
if [ ! -d "$INSTALL_DIR" ]; then warn "no install found at $INSTALL_DIR"; fi

if ! ask_yesno "Stop and remove SentinelCore containers?" y; then
    info "aborted — nothing changed"; exit 0
fi

if [ "$PURGE" = 1 ]; then
    run_sh "cd '$INSTALL_DIR' && $SUDO docker compose down -v --remove-orphans"
else
    run_sh "cd '$INSTALL_DIR' && $SUDO docker compose down --remove-orphans"
fi

# Firewall chain cleanup (M10 used a dedicated SENTINELCORE chain).
info "cleaning up firewall chain (SENTINELCORE), if present"
run_sh "$SUDO iptables -F SENTINELCORE 2>/dev/null; $SUDO iptables -X SENTINELCORE 2>/dev/null; true"

if [ "$PURGE" = 1 ]; then
    warn "PURGE: this permanently deletes SentinelCore data (DB, pcaps, reports)."
    if ask_yesno "Really delete all data and configuration under $INSTALL_DIR?" n; then
        run $SUDO systemctl disable --now sentinelcore.service 2>/dev/null || true
        run $SUDO rm -f /etc/systemd/system/sentinelcore.service
        run $SUDO systemctl daemon-reload 2>/dev/null || true
        # Shred secrets before removal.
        run_sh "$SUDO shred -u '$INSTALL_DIR/.env' 2>/dev/null || $SUDO rm -f '$INSTALL_DIR/.env'"
        run $SUDO rm -rf "$INSTALL_DIR"
        good "purged $INSTALL_DIR and systemd unit"
    else
        info "purge cancelled — containers stopped, data kept"
    fi
else
    good "containers stopped; data volumes and $INSTALL_DIR/.env kept"
fi
good "uninstall complete"
