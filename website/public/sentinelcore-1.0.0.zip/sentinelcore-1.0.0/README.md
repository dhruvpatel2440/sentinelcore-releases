# SentinelCore 1.0.0

Network detection & incident-response platform. One `docker compose` stack on
a single Linux host.

## Install
```bash
cd sentinelcore-1.0.0
sudo ./install.sh
```
See `docs/QUICKSTART.md` and `docs/REQUIREMENTS.md`.

## What's in this package
- `install.sh`, `uninstall.sh` — guided installer / teardown
- `templates/` — `.env.template`, `docker-compose.release.yml`, `nginx.release.conf`, `suricata.yaml.template`
- `images/` — offline Docker image tarball(s)
- `docs/` — quick start and requirements
- `VERSION`, `SHA256SUMS`

## Integrity
Verify before install:
```bash
sha256sum -c SHA256SUMS
```

All secrets are generated locally at install time. No credentials ship in this
package.
