# shellcheck shell=bash
# product.sh — product-level release configuration. Values here are fixed per
# build (not operator-chosen). Change RELAY_URL in ONE place to repoint every
# future build at a different relay host.

# Central email relay base URL (Phase 05 service). Override at runtime only for
# testing; the shipped value is authoritative.
RELAY_URL="${RELAY_URL:-https://relay.sentinelcore.app}"
