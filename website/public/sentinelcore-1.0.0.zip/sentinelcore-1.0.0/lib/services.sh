# shellcheck shell=bash
# services.sh — verify image checksums, load images, render runtime config,
# bring the stack up, and wait for healthchecks. Installs a systemd unit so
# the stack starts on boot.

INSTALL_DIR="${INSTALL_DIR:-/opt/sentinelcore}"

verify_images() {
    step "Verify bundled images"
    if [ ! -f "$PKG_DIR/SHA256SUMS" ]; then warn "no SHA256SUMS to verify"; return 0; fi
    if [ "${DRY_RUN:-0}" = 1 ]; then info "[dry-run] sha256sum -c SHA256SUMS (images/)"; return 0; fi
    ( cd "$PKG_DIR" && grep ' images/' SHA256SUMS | sha256sum -c - ) \
        && good "image checksums verified" || { err "image checksum mismatch"; return 1; }
}

stage_install_dir() {
    step "Stage install directory ($INSTALL_DIR)"
    local SUDO=""; [ "$(id -u)" -eq 0 ] || SUDO="sudo"
    run $SUDO mkdir -p "$INSTALL_DIR"
    # Runtime files: compose, configs, CA bundle, static frontend.
    run $SUDO cp "$PKG_DIR/templates/docker-compose.release.yml" "$INSTALL_DIR/docker-compose.yml"
    run $SUDO cp "$PKG_DIR/templates/nginx.release.conf" "$INSTALL_DIR/nginx.release.conf"
    # suricata.yaml: substitute HOME_NET to match MONITORED_NETWORK.
    if [ "${DRY_RUN:-0}" = 1 ]; then
        info "[dry-run] render suricata.yaml with HOME_NET=$MONITORED_NETWORK"
    else
        sed "s|__HOME_NET__|$MONITORED_NETWORK|g" "$PKG_DIR/templates/suricata.yaml.template" \
            | $SUDO tee "$INSTALL_DIR/suricata.yaml" >/dev/null
    fi
    if [ -d "$PKG_DIR/templates/frontend-dist" ]; then
        run $SUDO cp -a "$PKG_DIR/templates/frontend-dist" "$INSTALL_DIR/frontend-dist"
    else
        [ "${DRY_RUN:-0}" = 1 ] && info "[dry-run] copy static frontend-dist (present in a real build)"
    fi
    good "install directory staged"
}

load_images() {
    step "Load Docker images"
    local SUDO=""; [ "$(id -u)" -eq 0 ] || SUDO="sudo"
    local tar; tar="$(ls "$PKG_DIR"/images/sentinelcore-images-*.tar.gz 2>/dev/null | head -1 || true)"
    if [ "${DRY_RUN:-0}" = 1 ] && [ -z "$tar" ] && [ ! -f "$PKG_DIR/images/REGISTRY.txt" ]; then
        info "[dry-run] docker load -i images/sentinelcore-images-<version>.tar.gz"
        return 0
    fi
    if [ -n "$tar" ]; then
        run_sh "$SUDO docker load -i '$tar'"
    elif [ -f "$PKG_DIR/images/REGISTRY.txt" ]; then
        while read -r img; do [ -n "$img" ] && run $SUDO docker pull "$img"; done < "$PKG_DIR/images/REGISTRY.txt"
    else
        err "no images found (tarball or REGISTRY.txt) — cannot start"; return 1
    fi
    good "images available"
}

compose_up() {
    step "Start services"
    local SUDO=""; [ "$(id -u)" -eq 0 ] || SUDO="sudo"
    run_sh "cd '$INSTALL_DIR' && $SUDO docker compose --env-file .env up -d"
}

wait_healthy() {
    step "Wait for healthchecks"
    if [ "${DRY_RUN:-0}" = 1 ]; then info "[dry-run] poll 'docker compose ps' until backend+db+nginx healthy"; return 0; fi
    local SUDO=""; [ "$(id -u)" -eq 0 ] || SUDO="sudo"
    local i
    for i in $(seq 1 60); do
        if $SUDO docker compose -f "$INSTALL_DIR/docker-compose.yml" ps 2>/dev/null | grep -q 'healthy'; then
            good "services reporting healthy"; return 0
        fi
        sleep 3
    done
    err "services did not become healthy in time — see 'docker compose logs'"; return 1
}

install_systemd_unit() {
    step "Enable on boot (systemd)"
    local SUDO=""; [ "$(id -u)" -eq 0 ] || SUDO="sudo"
    local unit="/etc/systemd/system/sentinelcore.service"
    local body
    body="$(cat <<EOF
[Unit]
Description=SentinelCore stack
Requires=docker.service
After=docker.service network-online.target

[Service]
Type=oneshot
RemainAfterExit=yes
WorkingDirectory=$INSTALL_DIR
ExecStart=/usr/bin/docker compose --env-file $INSTALL_DIR/.env up -d
ExecStop=/usr/bin/docker compose down
TimeoutStartSec=0

[Install]
WantedBy=multi-user.target
EOF
)"
    if [ "${DRY_RUN:-0}" = 1 ]; then
        info "[dry-run] write $unit and 'systemctl enable sentinelcore.service'"
        printf '%s\n' "$body" | sed 's/^/    /'
        return 0
    fi
    printf '%s\n' "$body" | $SUDO tee "$unit" >/dev/null
    run $SUDO systemctl daemon-reload
    run $SUDO systemctl enable sentinelcore.service
    good "systemd unit installed"
}
