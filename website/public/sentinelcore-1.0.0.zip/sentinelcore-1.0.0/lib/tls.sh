# shellcheck shell=bash
# tls.sh — generate the install-local CA and the api.brevo.com certificate the
# relay shim presents. This is what lets the UNMODIFIED backend's verify=True
# egress to https://api.brevo.com trust the in-stack shim (see
# docs-internal/email-analysis.md). All material is install-local and never
# shipped. No-op when email is disabled.

gen_install_ca() {
    step "Install-local mail CA + shim certificate"
    if [ "${EMAIL_MODE:-off}" = off ]; then
        good "email disabled — skipping CA/cert generation"
        return 0
    fi
    local dir="$INSTALL_DIR/tls"
    if [ "${DRY_RUN:-0}" = 1 ]; then
        info "[dry-run] openssl: create CA -> $INSTALL_DIR/ca-bundle.pem"
        info "[dry-run] openssl: issue cert CN=api.brevo.com -> $dir/api.brevo.com.{crt,key}"
        return 0
    fi
    local SUDO=""; [ "$(id -u)" -eq 0 ] || SUDO="sudo"
    run $SUDO mkdir -p "$dir"
    # CA
    run_sh "$SUDO openssl genrsa -out '$dir/ca.key' 4096"
    run_sh "$SUDO openssl req -x509 -new -nodes -key '$dir/ca.key' -sha256 -days 3650 \
        -subj '/CN=SentinelCore Install CA' -out '$dir/ca.crt'"
    # Leaf cert for api.brevo.com (SAN).
    run_sh "$SUDO openssl genrsa -out '$dir/api.brevo.com.key' 2048"
    run_sh "printf 'subjectAltName=DNS:api.brevo.com' | $SUDO tee '$dir/san.ext' >/dev/null"
    run_sh "$SUDO openssl req -new -key '$dir/api.brevo.com.key' -subj '/CN=api.brevo.com' -out '$dir/api.csr'"
    run_sh "$SUDO openssl x509 -req -in '$dir/api.csr' -CA '$dir/ca.crt' -CAkey '$dir/ca.key' \
        -CAcreateserial -days 825 -sha256 -extfile '$dir/san.ext' -out '$dir/api.brevo.com.crt'"
    # Trust bundle the backend mounts as SSL_CERT_FILE: system roots + our CA so
    # the real internet still validates, plus the shim.
    run_sh "cat /etc/ssl/certs/ca-certificates.crt '$dir/ca.crt' 2>/dev/null | $SUDO tee '$INSTALL_DIR/ca-bundle.pem' >/dev/null || $SUDO cp '$dir/ca.crt' '$INSTALL_DIR/ca-bundle.pem'"
    run_sh "$SUDO chmod 600 '$dir/ca.key' '$dir/api.brevo.com.key'"
    good "install-local CA and api.brevo.com cert generated"
}
