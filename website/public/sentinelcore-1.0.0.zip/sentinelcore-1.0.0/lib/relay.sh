# shellcheck shell=bash
# relay.sh — register this install with the central email relay (Phase 05),
# receive a per-install token + sender address, and trigger the verification
# email to the admin. The real provider key never touches this box. No hidden
# calls: the ONLY endpoint contacted is $RELAY_URL/* (product.sh).

# RELAY_URL is defined in product.sh (sourced by install.sh). Keep a default
# so this module is usable standalone / in tests.
RELAY_URL="${RELAY_URL:-https://relay.sentinelcore.app}"

relay_install_id() {
    # Stable per-host id: machine-id when present, else hostname.
    local mid
    mid="$(cat /etc/machine-id 2>/dev/null || true)"
    [ -z "$mid" ] && mid="$(hostname 2>/dev/null || echo host)"
    printf 'sc-%s' "$mid"
}

relay_register() {
    step "Email relay registration"
    if [ "${EMAIL_MODE:-off}" = off ]; then
        good "email disabled (EMAIL_MODE=off) — skipping relay registration"
        return 0
    fi

    INSTALL_ID="${INSTALL_ID:-$(relay_install_id)}"
    info "registering with relay $RELAY_URL (admin: $ADMIN_EMAIL, install: $INSTALL_ID)"

    if [ "${DRY_RUN:-0}" = 1 ]; then
        info "[dry-run] POST $RELAY_URL/v1/register {admin_email, install_id, version} -> {token, sender_address}"
        info "[dry-run] relay emails a verification link to $ADMIN_EMAIL; token activates after /v1/verify"
        RELAY_TOKEN="__RELAY_TOKEN_DRYRUN__"; EMAIL_SENDER_ADDRESS="notify@sentinelcore.app"
        return 0
    fi

    local version resp
    version="$(cat "$PKG_DIR/VERSION" 2>/dev/null || echo dev)"
    resp="$(curl -fsS --max-time 15 -X POST "$RELAY_URL/v1/register" \
        -H 'content-type: application/json' \
        -d "{\"admin_email\":\"$ADMIN_EMAIL\",\"install_id\":\"$INSTALL_ID\",\"version\":\"$version\"}" 2>/dev/null)" || {
        warn "relay registration failed — email will remain disabled; configure later"
        EMAIL_MODE=off; return 0
    }

    RELAY_TOKEN="$(printf '%s' "$resp" | grep -o '"token"[ ]*:[ ]*"[^"]*"' | sed 's/.*"\([^"]*\)"$/\1/' || true)"
    EMAIL_SENDER_ADDRESS="$(printf '%s' "$resp" | grep -o '"sender_address"[ ]*:[ ]*"[^"]*"' | sed 's/.*"\([^"]*\)"$/\1/' || true)"
    if [ -z "$RELAY_TOKEN" ]; then
        warn "relay returned no token — disabling email"; EMAIL_MODE=off; return 0
    fi
    SECRETS[relay_token]="$RELAY_TOKEN"
    good "registered; per-install token stored (redacted)"
    warn "ACTION REQUIRED: open the verification link emailed to $ADMIN_EMAIL."
    warn "email sending stays disabled until that install is verified."
}
