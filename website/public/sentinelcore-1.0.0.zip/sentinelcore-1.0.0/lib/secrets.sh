# shellcheck shell=bash
# secrets.sh — openssl-based secret generation. Generated values go into the
# SECRETS associative array so ui.sh redacts them from all logs/output.

gen_hex()    { openssl rand -hex "${1:-32}"; }
gen_b64()    { openssl rand -base64 "${1:-24}" | tr -d '\n' | tr '+/' '-_' | tr -d '='; }

gen_password() {
    # URL/shell-safe strong password of length $1 (default 24).
    local len="${1:-24}"
    openssl rand -base64 48 | tr -d '\n' | tr -d '+/=' | cut -c1-"$len"
}

generate_secrets() {
    # Populate SECRETS[...] once. Idempotent within a run.
    declare -gA SECRETS 2>/dev/null || true
    [ "${SECRETS_INITIALIZED:-0}" = 1 ] && return 0
    SECRETS[postgres_password]="$(gen_password 28)"
    SECRETS[secret_key]="$(gen_hex 32)"
    SECRETS[webhook_secret]="$(gen_hex 32)"
    SECRETS_INITIALIZED=1
    log INFO "secrets generated (values redacted)"
}
