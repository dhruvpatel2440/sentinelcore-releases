# shellcheck shell=bash
# admin.sh — create the first admin using the APP'S OWN mechanism
# (scripts.seed_admin via the backend container), then verify login against
# the local API. The password is passed once to the container env for this
# one-shot run and is never written to .env.

INSTALL_DIR="${INSTALL_DIR:-/opt/sentinelcore}"

create_admin() {
    step "Create administrator"
    local SUDO=""; [ "$(id -u)" -eq 0 ] || SUDO="sudo"

    if [ -n "${ADMIN_PASSWORD:-}" ]; then
        SECRETS[admin_password]="$ADMIN_PASSWORD"
        info "seeding admin '$ADMIN_USERNAME' with the supplied password (via app's seed_admin)"
        # Pass the password only as a one-shot env to the app's own script.
        run_sh "cd '$INSTALL_DIR' && $SUDO docker compose run --rm -e SEED_ADMIN_USERNAME='$ADMIN_USERNAME' -e SEED_ADMIN_EMAIL='$ADMIN_EMAIL' -e SEED_ADMIN_PASSWORD='$ADMIN_PASSWORD' backend python -m scripts.seed_admin"
    else
        info "no password supplied — the app will generate one on first boot and print it to logs"
        if [ "${DRY_RUN:-0}" = 1 ]; then
            info "[dry-run] docker compose logs backend | grep 'GENERATED PASSWORD'"
        else
            local gen
            gen="$($SUDO docker compose -f "$INSTALL_DIR/docker-compose.yml" logs backend 2>/dev/null | sed -n '/GENERATED PASSWORD/{n;p;}' | head -1 | sed 's/^[[:space:]]*//' || true)"
            [ -n "$gen" ] && { SECRETS[admin_password]="$gen"; ADMIN_GENERATED_PASSWORD="$gen"; good "captured generated admin password (shown once at the end)"; }
        fi
    fi
}

verify_login() {
    step "Verify admin login"
    if [ "${DRY_RUN:-0}" = 1 ]; then
        info "[dry-run] POST http://127.0.0.1:$WEB_PORT/api/auth/login (expect 200)"
        return 0
    fi
    local pw="${ADMIN_PASSWORD:-${ADMIN_GENERATED_PASSWORD:-}}"
    [ -z "$pw" ] && { warn "no password available to verify login — skipping"; return 0; }
    local code
    code="$(curl -fsS -o /dev/null -w '%{http_code}' --max-time 10 \
        -X POST "http://127.0.0.1:$WEB_PORT/api/auth/login" \
        -H 'content-type: application/json' \
        -d "{\"username\":\"$ADMIN_USERNAME\",\"password\":\"$pw\"}" 2>/dev/null || echo 000)"
    case "$code" in
        200|204) good "admin login verified (HTTP $code)" ;;
        *) warn "admin login check returned HTTP $code — verify manually" ;;
    esac
}
