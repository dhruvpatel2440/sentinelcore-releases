# shellcheck shell=bash
# deps.sh — ensure Docker Engine + compose plugin. If missing, explain and ask
# consent, then install from Docker's OFFICIAL apt repo (never curl|bash).

docker_present() { command -v docker >/dev/null 2>&1 && docker compose version >/dev/null 2>&1; }

ensure_docker() {
    step "Dependencies"
    if docker_present; then good "Docker Engine + compose plugin present"; return 0; fi

    warn "Docker Engine and/or the compose plugin are not installed."
    info "SentinelCore runs entirely as Docker containers; this is required."
    if ! ask_yesno "Install Docker from Docker's official apt repository now? (needs sudo)" y; then
        err "Docker is required — aborting. Install it and re-run."
        return 1
    fi

    local SUDO=""; [ "$(id -u)" -eq 0 ] || SUDO="sudo"
    # Official Docker repo steps (Debian/Ubuntu), each via run() so dry-run prints them.
    run $SUDO install -m 0755 -d /etc/apt/keyrings
    run_sh "$SUDO curl -fsSL https://download.docker.com/linux/ubuntu/gpg -o /etc/apt/keyrings/docker.asc"
    run $SUDO chmod a+r /etc/apt/keyrings/docker.asc
    run_sh 'echo "deb [arch=$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/docker.asc] https://download.docker.com/linux/ubuntu $(. /etc/os-release && echo "$VERSION_CODENAME") stable" | '"$SUDO"' tee /etc/apt/sources.list.d/docker.list >/dev/null'
    run_sh "$SUDO apt-get update"
    run $SUDO apt-get install -y docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin
    run $SUDO systemctl enable --now docker

    if [ "${DRY_RUN:-0}" = 1 ]; then good "[dry-run] Docker install steps printed"; return 0; fi
    docker_present && good "Docker installed" || { err "Docker install did not complete"; return 1; }
}
