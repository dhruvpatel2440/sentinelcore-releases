# shellcheck shell=bash
# sensors.sh — network interface + capture-capability detection. The operator
# confirms the monitoring interface; promiscuous mode requires explicit
# consent. Read-only detection; enabling happens in services.sh.

list_interfaces() {
    # Emit "name state ipv4" lines, excluding loopback and container ifaces.
    if command -v ip >/dev/null 2>&1; then
        ip -o link show 2>/dev/null | awk -F': ' '{print $2}' | while read -r n; do
            case "$n" in lo|docker*|veth*|br-*|virbr*) continue ;; esac
            local st ip4
            st="$(ip -o link show "$n" 2>/dev/null | grep -o 'state [A-Z]*' | awk '{print $2}')"
            ip4="$(ip -o -4 addr show "$n" 2>/dev/null | awk '{print $4}' | head -1)"
            printf '%s %s %s\n' "$n" "${st:-?}" "${ip4:-none}"
        done
    fi
}

suggest_network() {
    # Derive a default MONITORED_NETWORK and PROTECTED_IPS from routes.
    # Guarded so a box without `ip` (e.g. preview on non-Linux) still works.
    local gw="" dev="" cidr="" dns="" self=""
    if command -v ip >/dev/null 2>&1; then
        gw="$(ip route 2>/dev/null | awk '/default/{print $3; exit}' || true)"
        dev="$(ip route 2>/dev/null | awk '/default/{print $5; exit}' || true)"
        cidr="$(ip -o -4 addr show "$dev" 2>/dev/null | awk '{print $4}' | head -1 || true)"
    fi
    dns="$(awk '/^nameserver/{print $2; exit}' /etc/resolv.conf 2>/dev/null || true)"
    self="${cidr%%/*}"
    SUGGEST_MONITORED_NETWORK="${cidr:-192.168.1.0/24}"
    SUGGEST_PROTECTED_IPS="$(printf '%s' "${gw:+$gw,}${dns:+$dns,}${self:-192.168.1.1}" | sed 's/,$//')"
    SUGGEST_CAPTURE_IFACE="${dev:-eth0}"
}

detect_capture_capability() {
    # Warn if the chosen iface is the one carrying the default route (mgmt NIC).
    local iface="$1" mgmt=""
    command -v ip >/dev/null 2>&1 && mgmt="$(ip route 2>/dev/null | awk '/default/{print $5; exit}' || true)"
    if [ "$iface" = "$mgmt" ]; then
        warn "interface '$iface' carries the default route (management NIC)."
        warn "for real visibility use a dedicated mirror/SPAN capture port."
        return 1
    fi
    good "interface '$iface' is not the management NIC — suitable for capture"
    return 0
}

sensor_step() {
    step "Sensor detection"
    info "detected interfaces (name / state / ipv4):"
    local lines; lines="$(list_interfaces)"
    printf '%s\n' "${lines:-  (none detected)}" | sed 's/^/  /'
    suggest_network

    # Build a whiptail menu of interfaces (tag = name, label = state+ip).
    local args=() n s i
    while read -r n s i; do [ -n "$n" ] && args+=("$n" "state=$s ip=$i"); done <<<"$lines"
    [ "${#args[@]}" -eq 0 ] && args=("${SUGGEST_CAPTURE_IFACE}" "suggested")

    CAPTURE_INTERFACE="${CAPTURE_INTERFACE:-$SUGGEST_CAPTURE_IFACE}"
    ask_menu CAPTURE_INTERFACE "Select the monitoring (capture) interface" "${args[@]}"
    detect_capture_capability "$CAPTURE_INTERFACE" || true

    info "this enables the Suricata sensor (passive IDS) and the privileged"
    info "helper (nmap discovery, firewall containment) on '$CAPTURE_INTERFACE'."
    if ask_yesno "Enable promiscuous capture on '$CAPTURE_INTERFACE'?" y; then
        PROMISC_CONSENT=1; good "promiscuous capture approved for $CAPTURE_INTERFACE"
    else
        PROMISC_CONSENT=0; warn "promiscuous capture declined — sensor will see limited traffic"
    fi
}
