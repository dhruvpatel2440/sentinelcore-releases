# shellcheck shell=bash
# config.sh — collect operator answers, validate them, and render .env from
# templates/.env.template (placeholders only). Admin password is NEVER written
# to .env; it is passed once to the bootstrap step and hashed by the app.
#
# Validation functions are pure (no I/O, no globals) so they can be unit-tested
# with bats. They echo nothing and return 0/1.

# ---- pure validators -----------------------------------------------------
valid_email()   { printf '%s' "$1" | grep -Eq '^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$'; }
valid_username(){ printf '%s' "$1" | grep -Eq '^[a-z_][a-z0-9_-]{2,31}$'; }
valid_cidr()    { printf '%s' "$1" | grep -Eq '^([0-9]{1,3}\.){3}[0-9]{1,3}/[0-9]{1,2}$'; }
valid_ipv4()    { printf '%s' "$1" | grep -Eq '^([0-9]{1,3}\.){3}[0-9]{1,3}$'; }
valid_port()    { case "$1" in ''|*[!0-9]*) return 1 ;; esac; [ "$1" -ge 1 ] && [ "$1" -le 65535 ]; }
valid_iface()   { printf '%s' "$1" | grep -Eq '^[A-Za-z0-9._-]{1,15}$'; }

strong_password() {
    # >=12 chars, with at least one lower, upper, and digit.
    local p="$1"
    [ "${#p}" -ge 12 ] || return 1
    printf '%s' "$p" | grep -q '[a-z]' || return 1
    printf '%s' "$p" | grep -q '[A-Z]' || return 1
    printf '%s' "$p" | grep -q '[0-9]' || return 1
    return 0
}

valid_protected_ips() {
    # comma-separated list of IPv4 addresses (non-empty).
    local list="$1" ip IFS=,
    [ -n "$list" ] || return 1
    for ip in $list; do valid_ipv4 "${ip// /}" || return 1; done
    return 0
}

# ---- collection ----------------------------------------------------------
collect_config() {
    step "Configuration"
    ask_input  ADMIN_EMAIL "Administrator email" "${ADMIN_EMAIL:-}"
    ask_input  ADMIN_USERNAME "Administrator username" "${ADMIN_USERNAME:-admin}"
    ask_secret ADMIN_PASSWORD "Administrator password (>=12, upper+lower+digit)"
    ask_input  MONITORED_NETWORK "Monitored network (CIDR)" "${MONITORED_NETWORK:-${SUGGEST_MONITORED_NETWORK:-}}"
    ask_input  PROTECTED_IPS "Protected IPs (gateway,DNS,self — never blocked)" "${PROTECTED_IPS:-${SUGGEST_PROTECTED_IPS:-}}"
    ask_input  WEB_PORT "Web port" "${WEB_PORT:-80}"
    ask_input  BIND_ADDRESS "Bind address (127.0.0.1 = local only)" "${BIND_ADDRESS:-127.0.0.1}"
    ask_input  APP_BASE_URL "App base URL (used in email links)" "${APP_BASE_URL:-http://$BIND_ADDRESS:$WEB_PORT}"
    ask_input  TIMEZONE "Timezone" "${TIMEZONE:-$(cat /etc/timezone 2>/dev/null || echo UTC)}"
    if [ "${BIND_ADDRESS}" = "0.0.0.0" ]; then
        warn "bind 0.0.0.0 exposes the UI on all interfaces — ensure a firewall/TLS in front."
    fi
}

validate_config() {
    step "Validate inputs"
    local rc=0
    valid_email "$ADMIN_EMAIL"            || { err "invalid admin email: $ADMIN_EMAIL"; rc=1; }
    valid_username "$ADMIN_USERNAME"      || { err "invalid username (3-32, [a-z0-9_-], must start a-z/_)"; rc=1; }
    if [ "${NON_INTERACTIVE:-0}" = 1 ] || [ "${DRY_RUN:-0}" = 1 ]; then
        if [ -n "${ADMIN_PASSWORD:-}" ]; then
            strong_password "$ADMIN_PASSWORD" || { err "admin password too weak (>=12, upper+lower+digit)"; rc=1; }
        else
            info "no admin password supplied — one will be generated on first boot"
        fi
    else
        strong_password "$ADMIN_PASSWORD" || { err "admin password too weak (>=12, upper+lower+digit)"; rc=1; }
    fi
    valid_cidr "$MONITORED_NETWORK"       || { err "invalid monitored network CIDR: $MONITORED_NETWORK"; rc=1; }
    valid_protected_ips "$PROTECTED_IPS"  || { err "invalid protected IPs: $PROTECTED_IPS"; rc=1; }
    valid_port "$WEB_PORT"                || { err "invalid web port: $WEB_PORT"; rc=1; }
    valid_ipv4 "$BIND_ADDRESS"            || { err "invalid bind address: $BIND_ADDRESS"; rc=1; }
    valid_iface "${CAPTURE_INTERFACE:-eth0}" || { err "invalid capture interface: ${CAPTURE_INTERFACE:-}"; rc=1; }
    [ "$rc" = 0 ] && good "inputs valid"
    return "$rc"
}

# ---- .env rendering ------------------------------------------------------
render_env() {
    # render_env <template> <out-path>  — substitute placeholders, mode 600.
    local tmpl="$1" out="$2"
    [ -f "$tmpl" ] || { err "template not found: $tmpl"; return 1; }
    generate_secrets

    local email_mode="${EMAIL_MODE:-off}"
    local relay_token="${RELAY_TOKEN:-}"
    local sender="${EMAIL_SENDER_ADDRESS:-}"

    # Build the rendered content in memory, then write with a tight umask.
    local content
    content="$(sed \
        -e "s|__GENERATED__|PLACEHOLDER|g" \
        "$tmpl")"
    # Targeted, unambiguous replacements (avoid clobbering with one global sub).
    content="$(printf '%s\n' "$content" \
        | sed -e "s|^POSTGRES_PASSWORD=.*|POSTGRES_PASSWORD=${SECRETS[postgres_password]}|" \
              -e "s|^SECRET_KEY=.*|SECRET_KEY=${SECRETS[secret_key]}|" \
              -e "s|^BREVO_WEBHOOK_SECRET=.*|BREVO_WEBHOOK_SECRET=${SECRETS[webhook_secret]}|" \
              -e "s|^DATABASE_URL=.*|DATABASE_URL=postgresql+asyncpg://sentinelcore:${SECRETS[postgres_password]}@localhost:5433/sentinelcore|" \
              -e "s|__ADMIN_EMAIL__|${ADMIN_EMAIL}|g" \
              -e "s|^SEED_ADMIN_USERNAME=.*|SEED_ADMIN_USERNAME=${ADMIN_USERNAME}|" \
              -e "s|__CAPTURE_INTERFACE__|${CAPTURE_INTERFACE:-eth0}|g" \
              -e "s|__MONITORED_NETWORK__|${MONITORED_NETWORK}|g" \
              -e "s|__PROTECTED_IPS__|${PROTECTED_IPS}|g" \
              -e "s|__EMAIL_MODE__|${email_mode}|g" \
              -e "s|__RELAY_TOKEN__|${relay_token}|g" \
              -e "s|__SENDER_ADDRESS__|${sender}|g" \
              -e "s|__APP_BASE_URL__|${APP_BASE_URL}|g" )"

    if [ "${DRY_RUN:-0}" = 1 ]; then
        info "[dry-run] would write $out (mode 600). Rendered keys:"
        printf '%s\n' "$content" | grep -E '^[A-Z_]+=' | sed -E 's/=(.*)/=<set>/' | sed 's/^/    /'
        return 0
    fi
    ( umask 077; printf '%s\n' "$content" > "$out" )
    chmod 600 "$out"
    good "wrote $out (mode 600)"
}
