#!/usr/bin/env bash
# SentinelCore guided installer.
#
# Usage:
#   sudo ./install.sh                      guided TUI (whiptail, or plain-text)
#   ./install.sh --dry-run                 print every action, change nothing
#   ./install.sh --non-interactive --config FILE   automated install
#   ./install.sh --uninstall               delegate to uninstall.sh
#   ./install.sh --help
#
# Safety: set -euo pipefail, trap cleanup, full redacted log at
# /var/log/sentinelcore-install.log. Idempotent: an existing install offers
# Repair / Upgrade / Abort. Never curl|bash. No telemetry.
set -euo pipefail

HERE="$(cd "$(dirname "$0")" && pwd)"

# The package root (where templates/, images/, docs/ live). When run from the
# unzipped package, that is HERE; in the dev tree, fall back to build/overlay.
if [ -d "$HERE/templates" ]; then PKG_DIR="$HERE"; else PKG_DIR="$HERE/../build/overlay"; fi
LIB="$HERE/lib"
TEMPLATE_ENV="$PKG_DIR/templates/.env.template"
INSTALL_DIR="${INSTALL_DIR:-/opt/sentinelcore}"
LOG_FILE="${LOG_FILE:-/var/log/sentinelcore-install.log}"

# Flags / state
DRY_RUN=0
NON_INTERACTIVE=0
CONFIG_FILE=""
EMAIL_MODE="${EMAIL_MODE:-off}"
declare -A SECRETS=()

while [ $# -gt 0 ]; do
    case "$1" in
        --dry-run) DRY_RUN=1; shift ;;
        --non-interactive) NON_INTERACTIVE=1; shift ;;
        --config) CONFIG_FILE="${2:?}"; shift 2 ;;
        --uninstall) exec "$HERE/uninstall.sh" "${@:2}" ;;
        -h|--help) sed -n '2,14p' "$0"; exit 0 ;;
        *) echo "unknown option: $1" >&2; exit 2 ;;
    esac
done

# If we can't write the system log (e.g. dry-run as non-root), use a temp log.
if ! { : >>"$LOG_FILE"; } 2>/dev/null; then
    LOG_FILE="${TMPDIR:-/tmp}/sentinelcore-install.log"
    { : >>"$LOG_FILE"; } 2>/dev/null || LOG_FILE="/dev/null"
fi

# shellcheck source=lib/ui.sh
for m in product ui checks secrets sensors config deps relay tls services admin; do
    # shellcheck disable=SC1090
    . "$LIB/$m.sh"
done

cleanup() {
    local rc=$?
    if [ "$rc" -ne 0 ] && [ "$DRY_RUN" = 0 ]; then
        err "install failed (exit $rc). Log: $LOG_FILE"
        warn "nothing was started if this failed before 'compose up'. To retry: re-run install.sh (Repair)."
    fi
}
trap cleanup EXIT

load_config_file() {
    [ -n "$CONFIG_FILE" ] || return 0
    [ -f "$CONFIG_FILE" ] || { err "config file not found: $CONFIG_FILE"; exit 2; }
    # Only accept KEY=VALUE lines; ignore everything else (no code execution).
    local k v
    while IFS='=' read -r k v; do
        case "$k" in ''|\#*) continue ;; esac
        k="$(printf '%s' "$k" | tr -d '[:space:]')"
        printf -v "$k" '%s' "$v"
    done < "$CONFIG_FILE"
    good "loaded config: $CONFIG_FILE"
}

detect_existing() {
    [ -f "$INSTALL_DIR/.env" ] || return 0
    warn "existing install detected at $INSTALL_DIR"
    local CHOICE=repair
    ask_menu CHOICE "An install already exists. What would you like to do?" \
        repair "Repair — re-apply config & restart services (keeps .env + data)" \
        upgrade "Upgrade — load new images & recreate containers (keeps data)" \
        abort "Abort — make no changes"
    case "$CHOICE" in
        abort) info "aborting at operator request"; exit 0 ;;
        repair) MODE_EXISTING=repair; warn "repair mode: will NOT overwrite .env or data" ;;
        upgrade) MODE_EXISTING=upgrade; warn "upgrade mode: will load new images, keep .env + data" ;;
    esac
}

welcome() {
    step "SentinelCore installer"
    info "version: $(cat "$PKG_DIR/VERSION" 2>/dev/null || echo 'dev')"
    info "This installs the SentinelCore stack (Docker Compose) on this host."
    info "Notice: lab/authorized-network use only. No telemetry. Log: $LOG_FILE"
    verify_images || exit 1
}

main() {
    load_config_file
    welcome
    MODE_EXISTING=""
    detect_existing

    run_system_checks || { err "system checks failed"; exit 1; }
    ensure_docker || exit 1
    sensor_step

    if [ "$MODE_EXISTING" = upgrade ]; then
        load_images; compose_up; wait_healthy
        final_screen; return 0
    fi

    collect_config
    validate_config || { err "please correct inputs and re-run"; exit 1; }

    relay_register

    if [ "$MODE_EXISTING" = repair ]; then
        warn "repair: keeping existing $INSTALL_DIR/.env"
    else
        render_env "$TEMPLATE_ENV" "$INSTALL_DIR/.env" || exit 1
    fi

    load_images
    stage_install_dir
    gen_install_ca
    compose_up
    wait_healthy || exit 1
    create_admin
    verify_login
    install_systemd_unit
    final_screen
}

final_screen() {
    local url="http://${BIND_ADDRESS:-127.0.0.1}:${WEB_PORT:-80}/"
    step "Installation complete"
    cat <<EOF
  SentinelCore is installed.

  ✓ dependencies   Docker Engine + compose
  ✓ database       PostgreSQL (container)
  ✓ sensors        Suricata + helper on ${CAPTURE_INTERFACE:-?}
  ✓ environment    $INSTALL_DIR/.env (mode 600)
  ✓ services       started, healthchecks passed
  email            ${EMAIL_MODE}

  Admin email : ${ADMIN_EMAIL:-?}
  Admin user  : ${ADMIN_USERNAME:-admin}
EOF
    if [ -n "${ADMIN_GENERATED_PASSWORD:-}" ]; then
        cat <<EOF
  Admin password (generated — store it now, shown ONCE):
      ${ADMIN_GENERATED_PASSWORD}
EOF
    else
        echo "  Admin password : (the one you chose)"
    fi
    cat <<EOF

  Open SentinelCore:  $url
  Logs            :  $LOG_FILE  and  docker compose -f $INSTALL_DIR/docker-compose.yml logs
  Uninstall       :  sudo $INSTALL_DIR/uninstall.sh   (add --purge to remove data)
EOF
    if command -v xdg-open >/dev/null 2>&1 && [ "${DRY_RUN:-0}" = 0 ] && [ -n "${DISPLAY:-}" ]; then
        xdg-open "$url" >/dev/null 2>&1 || true
    fi
}

main
